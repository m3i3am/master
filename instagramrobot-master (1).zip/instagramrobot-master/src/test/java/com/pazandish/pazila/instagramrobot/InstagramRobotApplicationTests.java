package com.pazandish.pazila.instagramrobot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InstagramRobotApplicationTests {

	@Test
	void contextLoads() {
	}

}
